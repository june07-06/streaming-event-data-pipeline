# Design and Trade-offs

- CSV and JSON keep outputs inspectable in Colab.
- Micro-batches provide manageable processing units.
- Source offsets support restart and replay protection.
- Event IDs provide business-level deduplication.
- Quarantine preserves invalid records for investigation.
- Late events are flagged and retained.
- Aggregates are rebuilt from accepted event history for reconciliation.
- This implementation is intended for learning and demonstration.
- A database, transactional sink, or Spark Structured Streaming is a
  reasonable next step for stronger recovery and larger workloads.
