# Streaming Event Processing Pipeline

## Objective
Simulate a continuously arriving stream of order events using micro-batches.
Validate records, deduplicate event IDs, detect late events, maintain
checkpoints, quarantine bad data, and publish hourly aggregates.

## Architecture
Synthetic producer -> CSV source -> micro-batch ingestion -> validation
-> accepted events / quarantine -> hourly aggregates and operational logs.

## Technology
Python, Pandas, NumPy, CSV, JSON, Google Colab.

## Source schema
event_id: required stable event identifier
order_id: required business order identifier
customer_id: required customer reference
event_time: ISO-8601 UTC timestamp
amount: finite non-negative number
status: created, paid, or cancelled
source_offset: positive unique source position

## Output files
output/accepted_events.csv
output/quarantine/rejected_events.csv
output/aggregates.csv
state/checkpoint.json
logs/run_metrics.csv

## Recovery
The checkpoint records the last committed source offset and maximum observed
event time. Output files are written before checkpoint advancement. A retry
skips already persisted source offsets. Event IDs prevent duplicate business
events from being accepted.

## Late events
Events more than 10 minutes behind the maximum event time observed are
flagged with is_late=True. They are retained rather than discarded.

## Data quality
Invalid records are quarantined with their original source fields and a
reject_reason. Unexpected schema changes fail the run.

## Reproducibility
The synthetic data generator uses a fixed random seed. The sample contains
intentional invalid records and duplicate delivery.

## Limitations
This is a single-process streaming simulation, not a production message
broker. CSV files and JSON checkpoints do not provide a fully transactional
commit across outputs and state. Stronger production guarantees require
transactional storage, durable state, and concurrency control.

## Run
Open the notebook in Google Colab and run the complete code cell.
