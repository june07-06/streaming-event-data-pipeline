# Data Dictionary

| Field | Type | Meaning |
|---|---|---|
| event_id | string | Stable event identifier |
| order_id | string | Order identifier |
| customer_id | string | Customer reference |
| event_time | UTC timestamp | Business event time |
| amount | float | Non-negative amount |
| status | string | Business event status |
| source_offset | integer | Source record position |
| run_id | string | Pipeline run identifier |
| is_late | boolean | Late event flag |
| reject_reason | string | Quarantine reason |
